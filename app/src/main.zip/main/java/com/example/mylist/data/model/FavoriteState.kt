package com.example.mylist.data.model

data class FavoriteState(
    val title: String = "",
    val type: String = "",
    val episodes: Int = 0
)
