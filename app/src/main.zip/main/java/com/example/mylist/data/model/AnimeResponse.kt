package com.example.mylist.data.model

data class AnimeResponse (
    val data: List<Anime>
)